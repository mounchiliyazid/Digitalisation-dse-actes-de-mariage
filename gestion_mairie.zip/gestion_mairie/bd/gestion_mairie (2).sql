-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2024 at 08:12 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gestion_mairie`
--

-- --------------------------------------------------------

--
-- Table structure for table `acte_mariage`
--

CREATE TABLE `acte_mariage` (
  `idacte` int(11) NOT NULL,
  `name_epoux` varchar(50) NOT NULL,
  `name_epouse` varchar(50) NOT NULL,
  `date_m` date NOT NULL,
  `age_epoux` varchar(50) NOT NULL,
  `profection_epoux` varchar(50) NOT NULL,
  `domicile_epoux` varchar(50) NOT NULL,
  `name_pere_fils` varchar(50) NOT NULL,
  `name_mere_fils` varchar(50) NOT NULL,
  `age_epouse` varchar(50) NOT NULL,
  `profection_epouse` varchar(50) NOT NULL,
  `domicile_epouse` varchar(50) NOT NULL,
  `name_pere_fille` varchar(50) NOT NULL,
  `name_mere_fille` varchar(50) NOT NULL,
  `regime_matrimoniale` varchar(50) NOT NULL,
  `chef_epoux` varchar(50) NOT NULL,
  `chef_epouse` varchar(50) NOT NULL,
  `temoin_epoux` varchar(50) NOT NULL,
  `temoin_epouse` varchar(50) NOT NULL,
  `dresser` varchar(50) NOT NULL,
  `officie_etat_civil` varchar(50) NOT NULL,
  `secretaire` varchar(50) NOT NULL,
  `date_le` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `acte_mariage`
--

INSERT INTO `acte_mariage` (`idacte`, `name_epoux`, `name_epouse`, `date_m`, `age_epoux`, `profection_epoux`, `domicile_epoux`, `name_pere_fils`, `name_mere_fils`, `age_epouse`, `profection_epouse`, `domicile_epouse`, `name_pere_fille`, `name_mere_fille`, `regime_matrimoniale`, `chef_epoux`, `chef_epouse`, `temoin_epoux`, `temoin_epouse`, `dresser`, `officie_etat_civil`, `secretaire`, `date_le`) VALUES
(1, '[value-2]', '[value-3]', '0000-00-00', '[value-5]', '[value-6]', '[value-7]', '[value-8]', '[value-9]', '[value-10]', '[value-11]', '[value-12]', '[value-13]', '[value-14]', '[value-15]', '[value-16]', '[value-17]', '[value-18]', '[value-19]', '[value-20]', '[value-21]', '[value-22]', '0000-00-00'),
(2, 'mounchili', 'issah yazid', '2024-04-24', 'deux mille deux', 'danse', 'lalal', 'inousa', 'jean', 'deux', 'menager', 'lolo', 'kakaka', 'koko', 'polygamie', 'looolo', 'lolol', 'titi', 'tata', 'mois meme', 'mairie iaia', 'foso', '2024-04-24'),
(3, 'yonchang charle', 'fotso ange', '2024-04-24', 'deux mille deux', 'ingenieur', 'popo', 'yonchang', 'eps yonchang', 'trois', 'developpeur', 'bedi', 'fotso jean', 'epse fotso', 'polygamie', 'yonchang', 'fotso', 'mony', 'papouka', 'mounchili issah yazid', 'bony love', ' paouka', '2024-04-23'),
(4, 'therie', 'yousouf', '2024-05-15', 'ff', 'fffff', 'fff', 'mounchili inoussa', 'mounchili inoussa', 'deux', 'menager', 'bedi', 'loli poumie', 'loli poumie', 'monogamie', 'ffr', 'fr', 'ff', 'ff', 'fff', 'fff', 'fff', '2024-05-21'),
(5, 'therie', 'yousouf', '2024-05-15', 'ff', 'fffff', 'fff', 'mounchili inoussa', 'mounchili inoussa', 'deux', 'menager', 'bedi', 'loli poumie', 'loli poumie', 'monogamie', 'ffr', 'fr', 'ff', 'ff', 'fff', 'fff', 'fff', '2024-05-21'),
(6, 'therie', 'yousouf', '2024-05-03', 'ff', 'fffff', 'fff', 'mounchili inoussa', 'mounchili inoussa', 'deux', 'menager', 'bedi', 'loli poumie', 'loli poumie', 'polygamie', 'ffr', 'fr', 'ff', 'ff', 'fff', 'fff', 'fff', '2024-06-01');

-- --------------------------------------------------------

--
-- Table structure for table `archive`
--

CREATE TABLE `archive` (
  `id_archive` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `iduser` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`iduser`, `name`, `surname`, `email`, `user_type`, `password`) VALUES
(2, 'mounchili', 'issah yazid', 'yaziddounya@gmail.com', 'admin', '81dc9bdb52d04dc20036dbd8313ed055'),
(3, 'tamjo', 'brioslin', 'tamjo@gmail.com', 'user', '83cdcec08fbf90370fcf53bdd56604ff'),
(4, 'mounchili', 'inoussa', 'yassi@gmail.com', 'admin', '4ebe7c58bc215459085a6bb82be271c0'),
(5, 'yazid', 'issah', 'yazid@gmail.com', 'admin', '81dc9bdb52d04dc20036dbd8313ed055'),
(6, 'yazid', 'issah', 'yazid@gmail.com', 'admin', '83cdcec08fbf90370fcf53bdd56604ff'),
(7, 'simon', 'carle', 'simon@gmail.com', 'user', '827ccb0eea8a706c4c34a16891f84e7b'),
(8, 'fotdo', 'simo', 'fotso@gmail.com', 'user', '827ccb0eea8a706c4c34a16891f84e7b'),
(9, 'YAZID', 'ISSA', 'ISSSAH@gmail.com', 'admin', '202cb962ac59075b964b07152d234b70'),
(10, 'CRERSUS', 'NGOUAMBE', 'ISSSAH@gmail.com', 'admin', 'ed657efedf9f32475e02366324650235'),
(11, 'charle', 'fotso', 'charle@gmail.com', 'user', '827ccb0eea8a706c4c34a16891f84e7b'),
(12, 'ange', 'as', 'as@gmail.com', 'user', '827ccb0eea8a706c4c34a16891f84e7b'),
(13, 'therie', 'yousouf', 'therie@gmail.com', 'admin', 'e10adc3949ba59abbe56e057f20f883e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acte_mariage`
--
ALTER TABLE `acte_mariage`
  ADD PRIMARY KEY (`idacte`);

--
-- Indexes for table `archive`
--
ALTER TABLE `archive`
  ADD PRIMARY KEY (`id_archive`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`iduser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acte_mariage`
--
ALTER TABLE `acte_mariage`
  MODIFY `idacte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `archive`
--
ALTER TABLE `archive`
  MODIFY `id_archive` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `iduser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
