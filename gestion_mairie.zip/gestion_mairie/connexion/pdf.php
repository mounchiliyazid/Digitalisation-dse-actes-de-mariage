<?php

use Dompdf\Dompdf;
require_once 'config.php';



  ob_start(); ?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=.0">
    <title>Document</title>
    <style>

    </style>
</head>
<body>
    
<page style="font-size:2pt; width: 2480px; height: 3508px;">
<table>
    <tr>
 <td>
         <p  style="margin-left: 40px; font-size:15px;">REPUBLIQUE DU CAMEROUN</p>
        <p style="margin-left: 70px; font-size:15px;">Paix – Travail – Patrie</p>
            <p style="margin-left: 90px; font-size:10px;">*********************</p>
 <p style="margin-left: 10px; font-size:15px;">MINISTERE DE L’ENSEIGNEMENT SUPERIEUR  </p>
<p style="margin-left: 90px; font-size:10px;">***********************</p>

<p style="margin-left: 20px; font-size:15px;">IAI–CAMEROUN – CENTRE DE DOUALA </p>

</td>
<td><img src="img.PNG" alt="" style="margin-left:120px;"></td>
<td style="margin-left: 100px; font-size:15px;">
         <p  style="margin-left: 220px; font-size:15px;">REPUBLIC OF CAMEROON</p>
        <p style="margin-left: 240px; font-size:15px;">Peace – Work – Fatherland</p>
            <p style="margin-left: 300px; font-size:15px;">*********************</p>
 <p style="margin-left: 190px; font-size:15px;">MINISTRY OF HIGHER EDUCATION</p>
<p style="margin-left: 300px; font-size:10px;">***********************</p>

<p style="margin-left: 170px; font-size:15px;">AICS – CAMEROON –DOUALA CENTER</p>

</td>
    
    </tr>
   


</table>

    <div style="display:inline-block;">
        <h1 style="margin-left: 300px; font-size:30px;">ACTE DE MARIAGE</h1>
        <h6 style="margin-left: 400px; font-size:20px;"><i>Marriage certificate</i></h6>
    </div>



    <?php
    
    if (isset($_GET['idacte'])) {
        # code...
        $idacte = intval($_GET['idacte']);
        $sql = "SELECT * FROM acte_mariage WHERE idacte = $idacte";
        $result = mysqli_query($conn, $sql);

             while ($row = mysqli_fetch_assoc($result)){?>

    <Table>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px; "><strong>Mariage de</strong>  - <i>marriage of   </i>   </p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-200px;"><strong> <?php echo $row['name_epoux']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>de _ </strong>  <i>and of</i></p></td>
                <td> <p style="font-size: 20px; margin-top:-15px;margin-left:-200px;"><strong> <?php echo $row['name_epouse']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>le</strong>  <i>on the</i></p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-200px;"><strong> <?php echo $row['date_m']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Devant nous, ont comparu publiquement</strong>  <i> Before us appeared publicly</i></p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>M.</strong> - <i>Mr</i></p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-200px;"><strong> <?php echo $row['name_epoux']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Age - </strong><i>-Aged</i></p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-200px;"><strong> <?php echo $row['age_epoux']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Profection -</strong><i> Occupation</i></p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-200px;"><strong> <?php echo $row['profection_epoux']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"> <strong>Domiciliee a-</strong><i>Resident at</i></p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-200px;"><strong> <?php echo $row['domicile_epoux']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"> <strong>Fille de -</strong><i>Doughter of</i></p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-200px;"><strong> <?php echo $row['name_pere_fils']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Et de -</strong><i>And of</i> </p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-200px;"><strong> <?php echo $row['name_mere_fils']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"> <strong>Les futurs époux déclarent que le contrat a été établi comme suit : </strong><i>marriage of</i>  </p>
                <p style="font-size: 15px; margin-top:-15px;"> <i>The bride and the bridegroom state that the marriage settelment has been established as follows:</i>  </p>
            </td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Régime matrimonial  -</strong><i> Type of antenuptial settlement</i></p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-100px;"><strong> <?php echo $row['regime_matrimoniale']?></strong> </p></td>
      </tr>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Il n'a été constaté aucune opposition </strong><i>—No objection to marriage have been recorded</i></p></td>
      </tr>

      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"> <strong>M. -</strong><i>Mr</i></p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-100px;"><strong> <?php echo $row['name_epoux']?></strong> </p></td>
      </tr>
                
                <td><p style="font-size: 20px; margin-left: 100px;"><strong>Et Mlle- </strong><i>-and Miss</i></p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:0px;"><strong> <?php echo $row['name_epouse']?></strong> </p></td>
      </tr>

      </tr>
      <tr>
                <td><p style="font-size: 18px; margin-top:-15px;"> <strong>Ont déclaré l'un après l'autre vouloir se prendre pour époux et Nous 
                avons prononcé, au nom de la loi, qu'ils sont unis par le 
               mariage</strong></p>
               <p style="font-size: 13px; margin-top:-15px;"> <i>Both declared they wish to be husband and wife in accordance with the law and we pronounce that they are united by the marriage.
</i>  </p>
            </td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>En présence de</strong><i>- In the presence of</i></p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Chef de famille de l'époux ou son représentant :</strong></p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-100px;"><strong> <?php echo $row['chef_epoux']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Chef de famille de l'épouse ou son représentant</strong></p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-100px;"><strong> <?php echo $row['chef_epouse']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Qui consentent au mariage -</strong><i>who agree to the marriage</i> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Témoin de l'époux-</strong><i>Witness of the husband</i> </p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-100px;"><strong> <?php echo $row['temoin_epoux']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Témoin de l'épouse </strong>-<i>Witness of the wife</i> </p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-100px;"><strong> <?php echo $row['temoin_epouse']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Le présent acte a été dressé par nous </strong></i> </p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-300px;"><strong> <?php echo $row['dresser']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Officier de l'Etat-civil du centre de </strong></i> </p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-300px;"><strong> <?php echo $row['officie_etat_civil']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Assisté de Secrétaire d'Etat-civil </strong></i> </p></td>
                <td> <p style="font-size: 20px; margin-top:-15px; margin-left:-300px;"><strong> <?php echo $row['secretaire']?></strong> </p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Signature des époux </strong> <i style="font-size: 10px; margin-top:-15px;">Bride and bridegroom signature</i></p> </td>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>La Haye, le</strong></p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Signature des témoins - </strong><i style="font-size: 10px; margin-top:-15px;">— Witnesses signature </i></p> </td>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Signature de l'Officier d'Etat-civil</strong>
                <i>Signature of Civil status Registrar</i></p></td>
      </tr>
      <tr>
                <td><p style="font-size: 20px; margin-top:-15px;"><strong>Le Secrétaire — Secretary</strong></i> </p></td>
      </tr>
 <?php
    
                   }
                }
               
        
?>
      
    </Table>
</page_header>
</body>
</html>
<?php
$html = ob_get_contents();
ob_end_clean();



require_once 'dompdf/autoload.inc.php';

$dompdf = new Dompdf();

$dompdf->setPaper('A3','protrait');

$dompdf->loadhtml($html);
$dompdf->render();

$fichier = 'acte_de_mariage.pdf';
$dompdf->stream($fichier);

