<?php
$conn = mysqli_connect('localhost','root','','gestion_mairie') or die('connection failed');

?>
