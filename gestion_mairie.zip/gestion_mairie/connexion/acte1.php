<?php 
include 'config.php';

session_start();


if (isset($_POST['submit'])) {
    $epoux = $_POST['name_epoux'];
    $epouse = $_POST['name_epouse'];
    $a = $_POST['date_m'];
    $b = $_POST['age_epoux'];
	$c = $_POST['profection_epoux'];
	$d = $_POST['domicile_epoux'];
	$f = $_POST['name_pere_fils'];
	$g = $_POST['name_mere_fils'];
	$h = $_POST['age_epouse'];
	$i = $_POST['profection_epouse'];
	$j = $_POST['domicile_epouse'];
	$k = $_POST['name_pere_fille'];
	$l = $_POST['name_mere_fille'];
	$m = $_POST['regime_matrimoniale'];
	$n = $_POST['chef_epoux'];
	$o = $_POST['chef_epouse'];
	$p = $_POST['temoin_epoux'];
	$q = $_POST['temoin_epouse'];
	$r= $_POST['dresser'];
	$s = $_POST['officie_etat_civil'];
	$t = $_POST['secretaire'];
	$w= $_POST['date_le'];
    
    $sql = "INSERT INTO `acte_mariage`(`idacte`, `name_epoux`, `name_epouse`, `date_m`, `age_epoux`,  `profection_epoux`, `domicile_epoux`, `name_pere_fils`,`name_mere_fils`, `age_epouse`, `profection_epouse`,`domicile_epouse`, `name_pere_fille`, `name_mere_fille`, `regime_matrimoniale`, `chef_epoux`, `chef_epouse`, `temoin_epoux`, `temoin_epouse`, `dresser`, `officie_etat_civil`, `secretaire`, `date_le`) VALUES (NULL,'$epoux','$epouse','$a','$b','$c','$d','$f','$g','$h','$i','$j','$k','$l','$m','$n','$o','$p','$q','$r','$s','$t','$w')";

    $result = mysqli_query($conn, $sql);
     if ($result) {
         header("location: ../table/index.php?msg=couple enregistrer avec sussce");
         # code...
     }else {
         echo "error: " .mysqli_error($conn);
     }
    # code...

    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>inscription</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>

	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-form-title" style="background-image: url(images/12.jpg);">
					<span class="login100-form-title-1">
						enregistre  l'acte  de  mariage
					</span>
				</div>
                 <form action="" method="post" class="login100-form validate-form">
					<div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">nom de l'epoux</span>
						<input class="input100" type="text" name="name_epoux" placeholder="entre le nom de l'epoux">
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">nom de l'epouse</span>
						<input class="input100" type="text" name="name_epouse" placeholder="entre le nom de l'epouse">
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">le</span>
						<input class="input100" type="date" name="date_m" placeholder="entre la date de mariage">
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">age de l'epoux</span>
						<input class="input100" type="text" name="age_epoux" placeholder="age de l'epoux">
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">profession de l'epoux</span>
						<input class="input100" type="text" name="profection_epoux" placeholder="entre le profession de l'epoux">
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">domicile de l'epoux</span>
						<input class="input100" type="text" name="domicile_epoux" placeholder="entre le domicile de l'epoux">
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">pere de l'epoux</span>
						<input class="input100" type="text" name="name_pere_fils" placeholder="entre le nom de pere de l'epoux de l'epoux">
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">mere de l'epoux</span>
						<input class="input100" type="text" name="name_mere_fils" placeholder="entre le nom de mere de l'epoux de l'epoux">
						<span class="focus-input100"></span>
					</div>

                    <div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">age epouse</span>
						<input class="input100" type="text" name="age_epouse" placeholder="age l'epouse">
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">profession epouse</span>
						<input class="input100" type="text" name="profection_epouse" placeholder="profession de l'epouse">
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">domicile</span>
						<input class="input100" type="text" name="domicile_epouse" placeholder="domicile de l'epouse">
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">pere de l'epouse</span>
						<input class="input100" type="text" name="name_pere_fille" placeholder="nom du pere de l'epouse">
						<span class="focus-input100"></span>
					</div>
                    <div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">mere de l'epouse</span>
						<input class="input100" type="text" name="name_mere_fille" placeholder="nom de  la mere de l'epouse">
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-26" data-validate="Username is required">
						<span class="label-input100">regime matrimomiale</span>
						<select name="regime_matrimoniale" class="input100">
							<option value="polygamie">polygamie</option>
							<option value="monogamie">monogamie</option>
						</select>
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-18" data-validate = "Password is required">
						<span class="label-input100">chef famille </span>
						<input class="input100" type="text" name="chef_epoux" placeholder="chef famille de l'epoux">
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-18" data-validate = "Password is required">
						<span class="label-input100">chef famille </span>
						<input class="input100" type="text" name="chef_epouse" placeholder="chef famille de l'epouse">
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-18" data-validate = "Password is required">
						<span class="label-input100">temoin epoux</span>
						<input class="input100" type="text" name="temoin_epoux" placeholder="nom temoin de l'epoux">
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-18" data-validate = "Password is required">
						<span class="label-input100">temoin epouse</span>
						<input class="input100" type="text" name="temoin_epouse" placeholder="nom temoin de l'epouse">
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-18" data-validate = "Password is required">
						<span class="label-input100">dresser par</span>
						<input class="input100" type="text" name="dresser" placeholder="acte dresser par">
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-18" data-validate = "Password is required">
						<span class="label-input100"></span>
						<input class="input100" type="text" name="officie_etat_civil" placeholder="Le présent acte a été dressé par">
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-18" data-validate = "Password is required">
						<span class="label-input100"></span>
						<input class="input100" type="text" name="secretaire" placeholder="Assisté de Secrétaire d'Etat-civil">
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input m-b-18" data-validate = "Password is required">
						<span class="label-input100">fait le</span>
						<input class="input100" type="date" name="date_le" placeholder="">
						<span class="focus-input100"></span>
					</div>


					<div class="container-login100-form-btn">
                    <input type="submit" value="valider" class="login100-form-btn" name="submit">
					</div>
				</form>
			</div>
		</div>
	</div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>