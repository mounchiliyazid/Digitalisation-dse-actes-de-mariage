<?php 
include 'config.php';
?>

<!doctype html>
<html lang="en">
  <head>
  	<title>Table 05</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="css/style.css">

	</head>
	<body>
	<section class="ftco-section">
	<?php  
     #message en ca de reusite
        if (isset($_GET['msg'])) {
            $msg = $_GET['msg'];
            echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
            '.$msg.'
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="close"></button>
            </div>
            ';
            
        }
     ?>
		<div class="container">
			<div class="row justify-content-center">
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">
						<table class="table table-responsive-xl">
						  <thead>
						    <tr>
						    	<th>&nbsp;</th>
						    	<th>Nom du marie</th>
						      <th>nom de la mariee</th>
						      <th>regime matrimonaile</th>
						      <th>&nbsp;</th>
							  <th>&nbsp;</th>
						    </tr>
						  </thead>
						  <tbody>
							<?php
							$sql = "SELECT * FROM `acte_mariage`;";
							$result = mysqli_query($conn, $sql);
							while ($row = mysqli_fetch_assoc($result)) {
							
							?>
						    <tr class="alert" role="alert">
						    	<td>
						    		<label class="checkbox-wrap checkbox-primary">
										  <input type="checkbox" checked>
										  <span class="checkmark"></span>
										</label>
						    	</td>
						      <td class="-flex align-items-center">
						      	<div class="img" style="background-image: url(images/14.jpg);"></div>
						      	<div class="pl-3 email">
						      		<span><?php echo $row['name_epoux']?></span>
						      		<span><?php echo $row['profection_epoux']?></span>
						      	</div>
						      </td>
							  <td>
			
								<div class="img" style="background-image: url(images/14.jpg);"></div>
								<div class="pl-3 email">
									<span><?php echo $row['name_epouse']?></span>
									<span><?php echo $row['profection_epouse']?></span>
								</div>
							</td>
						      <td class="status"><span class="active"><?php echo $row['regime_matrimoniale']?></span></td>
							  							<td>
								<strong><a href="../connexion/pdf.php?idacte=<?php echo $row['idacte'] ?>">imprimer</a></strong>
							</td>
						      <td>
						      	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				            	<span aria-hidden="true"><i class="fa fa-close"></i></span>
				          	</button>
				        	</td>

						    </tr>
                             <?php
							}
							 ?>

						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>

