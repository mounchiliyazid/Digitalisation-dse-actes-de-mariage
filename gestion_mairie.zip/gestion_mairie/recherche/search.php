<?php
// Connexion à la base de données
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "gestion_mairie";
$port=3306;

$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Erreur de connexion à la base de données : " . $conn->connect_error);
}

// Récupérer la requête de recherche
$query = $_GET['query'];

// Préparer et exécuter la requête SQL
$stmt = $conn->prepare("SELECT * FROM acte_mariage WHERE name_epoux LIKE ?");
$searchQuery = "%" . $query . "%";
$stmt->bind_param("s", $searchQuery);
$stmt->execute();
$result = $stmt->get_result();

// Afficher les résultats de la recherche
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='result'>";
        echo "<h3>" . $row["name_epoux"] . "</h3>";
        echo "<p>" . $row["name_epouse"] . "</p>";
        echo "</div>";
    }
} else {
    echo "<p>Aucun résultat trouvé.</p>";
}

$stmt->close();
$conn->close();
?>